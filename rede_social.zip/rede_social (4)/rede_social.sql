-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 17/10/2025 às 02:26
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `rede_social`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `conteudo` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `comentarios`
--

INSERT INTO `comentarios` (`id`, `post_id`, `usuario_id`, `conteudo`, `created_at`) VALUES
(46, 32, 17, 'ai amoo', '2025-10-16 21:15:21'),
(47, 33, 18, 'ana marombaa', '2025-10-16 21:17:36'),
(48, 33, 19, 'fingindo que treina', '2025-10-16 21:18:48'),
(49, 32, 19, 'arrasou', '2025-10-16 21:19:11'),
(50, 35, 16, 'pra escola nao quer ir', '2025-10-16 21:24:13'),
(51, 34, 16, 'qual livroo', '2025-10-16 21:24:22'),
(52, 33, 16, 'KKAKKAKKKKK ctz @bianca', '2025-10-16 21:24:46');

-- --------------------------------------------------------

--
-- Estrutura para tabela `followers`
--

CREATE TABLE `followers` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `followed_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `followers`
--

INSERT INTO `followers` (`id`, `follower_id`, `followed_id`, `created_at`, `status`) VALUES
(31, 17, 16, '2025-10-17 00:16:18', 1),
(32, 18, 16, '2025-10-17 00:17:48', 1),
(33, 18, 17, '2025-10-17 00:17:54', 1),
(34, 19, 17, '2025-10-17 00:19:18', 1),
(35, 19, 18, '2025-10-17 00:19:23', 1),
(36, 19, 16, '2025-10-17 00:19:28', 1),
(37, 20, 17, '2025-10-17 00:21:05', 1),
(38, 20, 16, '2025-10-17 00:21:10', 1),
(39, 20, 18, '2025-10-17 00:21:16', 1),
(40, 20, 19, '2025-10-17 00:21:21', 1),
(41, 21, 16, '2025-10-17 00:23:23', 1),
(42, 21, 17, '2025-10-17 00:23:30', 1),
(43, 21, 18, '2025-10-17 00:23:35', 1),
(44, 21, 20, '2025-10-17 00:23:41', 1),
(45, 21, 19, '2025-10-17 00:23:46', 1),
(46, 16, 17, '2025-10-17 00:24:56', 1),
(47, 16, 21, '2025-10-17 00:25:02', 1),
(48, 16, 18, '2025-10-17 00:25:09', 1),
(49, 16, 20, '2025-10-17 00:25:17', 1),
(50, 16, 19, '2025-10-17 00:25:25', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `usuario_id`, `created_at`) VALUES
(54, 32, 17, '2025-10-16 21:15:18'),
(55, 33, 18, '2025-10-16 21:17:24'),
(56, 32, 18, '2025-10-16 21:17:42'),
(57, 33, 19, '2025-10-16 21:18:51'),
(58, 32, 19, '2025-10-16 21:19:01'),
(59, 32, 20, '2025-10-16 21:20:17'),
(60, 33, 20, '2025-10-16 21:20:19'),
(61, 34, 20, '2025-10-16 21:20:58'),
(62, 33, 21, '2025-10-16 21:22:05'),
(63, 34, 21, '2025-10-16 21:22:07'),
(64, 32, 21, '2025-10-16 21:22:10'),
(67, 33, 16, '2025-10-16 21:24:24'),
(68, 34, 16, '2025-10-16 21:24:27'),
(69, 35, 16, '2025-10-16 21:24:32'),
(70, 32, 16, '2025-10-16 21:24:34');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `conteudo` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `lida` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes`
--

CREATE TABLE `notificacoes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `usuario_acao_id` int(11) DEFAULT NULL,
  `origem_usuario_id` int(11) DEFAULT NULL,
  `tipo` enum('like','comentario','mensagem') NOT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `mensagem` varchar(255) DEFAULT NULL,
  `lida` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `notificacoes`
--

INSERT INTO `notificacoes` (`id`, `usuario_id`, `usuario_acao_id`, `origem_usuario_id`, `tipo`, `referencia_id`, `mensagem`, `lida`, `created_at`) VALUES
(73, 16, NULL, 17, 'like', 32, 'Curtiram sua publicação', 1, '2025-10-16 21:15:18'),
(74, 16, NULL, 17, 'comentario', 32, 'Comentou na sua publicação', 1, '2025-10-16 21:15:21'),
(75, 17, NULL, 18, 'like', 33, 'Curtiram sua publicação', 0, '2025-10-16 21:17:24'),
(76, 17, NULL, 18, 'comentario', 33, 'Comentou na sua publicação', 0, '2025-10-16 21:17:36'),
(77, 16, NULL, 18, 'like', 32, 'Curtiram sua publicação', 1, '2025-10-16 21:17:42'),
(78, 17, NULL, 19, 'comentario', 33, 'Comentou na sua publicação', 0, '2025-10-16 21:18:48'),
(79, 17, NULL, 19, 'like', 33, 'Curtiram sua publicação', 0, '2025-10-16 21:18:51'),
(80, 16, NULL, 19, 'like', 32, 'Curtiram sua publicação', 1, '2025-10-16 21:19:01'),
(81, 16, NULL, 19, 'comentario', 32, 'Comentou na sua publicação', 1, '2025-10-16 21:19:11'),
(82, 16, NULL, 20, 'like', 32, 'Curtiram sua publicação', 1, '2025-10-16 21:20:17'),
(83, 17, NULL, 20, 'like', 33, 'Curtiram sua publicação', 0, '2025-10-16 21:20:19'),
(84, 17, NULL, 21, 'like', 33, 'Curtiram sua publicação', 0, '2025-10-16 21:22:05'),
(85, 20, NULL, 21, 'like', 34, 'Curtiram sua publicação', 0, '2025-10-16 21:22:07'),
(86, 16, NULL, 21, 'like', 32, 'Curtiram sua publicação', 1, '2025-10-16 21:22:11'),
(87, 21, NULL, 16, 'like', 35, 'Curtiram sua publicação', 0, '2025-10-16 21:24:04'),
(88, 21, NULL, 16, 'comentario', 35, 'Comentou na sua publicação', 0, '2025-10-16 21:24:13'),
(89, 20, NULL, 16, 'like', 34, 'Curtiram sua publicação', 0, '2025-10-16 21:24:18'),
(90, 20, NULL, 16, 'comentario', 34, 'Comentou na sua publicação', 0, '2025-10-16 21:24:22'),
(91, 17, NULL, 16, 'like', 33, 'Curtiram sua publicação', 0, '2025-10-16 21:24:24'),
(92, 20, NULL, 16, 'like', 34, 'Curtiram sua publicação', 0, '2025-10-16 21:24:27'),
(93, 21, NULL, 16, 'like', 35, 'Curtiram sua publicação', 0, '2025-10-16 21:24:32'),
(94, 17, NULL, 16, 'comentario', 33, 'Comentou na sua publicação', 0, '2025-10-16 21:24:46');

-- --------------------------------------------------------

--
-- Estrutura para tabela `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `conteudo` text NOT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `posts`
--

INSERT INTO `posts` (`id`, `usuario_id`, `conteudo`, `imagem`, `created_at`) VALUES
(32, 16, 'Comprinhaass', 'uploads/68f18a4a12813_manupost.jpg', '2025-10-16 21:14:02'),
(33, 17, 'Gym time!', 'uploads/68f18ac871c27_gym.jpg', '2025-10-16 21:16:08'),
(34, 20, 'Peace', 'uploads/68f18be52db06_book.jpg', '2025-10-16 21:20:53'),
(35, 21, 'Buongiorno Italia!', 'uploads/68f18c7195956_plane.jpg', '2025-10-16 21:23:13');

-- --------------------------------------------------------

--
-- Estrutura para tabela `presence`
--

CREATE TABLE `presence` (
  `usuario_id` int(11) NOT NULL,
  `last_seen` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `presence`
--

INSERT INTO `presence` (`usuario_id`, `last_seen`) VALUES
(16, '2025-10-16 21:25:58');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `nivel` enum('membro','admin') NOT NULL DEFAULT 'membro',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `privado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `foto`, `nivel`, `last_login`, `created_at`, `privado`) VALUES
(16, 'Manuela Catarina', 'manulinda@gmail.com', '$2y$10$jRP1SzLqo1/LSTmI4i/e6.axTh0meAmcgJNsTa3b3ecoK4h4GYBqe', 'uploads/68f1890b7e437.jpg', 'membro', '2025-10-16 21:25:45', '2025-10-16 21:08:43', 0),
(17, 'Ana Vic', 'ana@gmail.com', '$2y$10$WiiXmSJepvnQhMdtAvv1fupOeaUgMMs4UhIW3uKhNIMRN/v0y2hce', 'uploads/68f18a8541830.jpg', 'membro', '2025-10-16 21:15:14', '2025-10-16 21:15:01', 0),
(18, 'Sophia Morgado', 'sophiam@gmail.com', '$2y$10$cTrEv5pCg4fIfpk8q8dLqeIxxTIKW2vzotgUpLrKxT4PdlIUY8F4q', 'uploads/68f18b0485241.jpg', 'membro', '2025-10-16 21:17:19', '2025-10-16 21:17:08', 0),
(19, 'Bianca Paiva', 'bianca@gmail.com', '$2y$10$dtOJx9zi9.z99QVDk3re3O3xRCzqBfzqBSQ/b1GfSny6sgyLh7H1a', 'uploads/68f18b5447bb7.jpg', 'membro', '2025-10-16 21:18:37', '2025-10-16 21:18:28', 0),
(20, 'Sophia Ruiz', 'sophiar@gmail.com', '$2y$10$A8KCgoSB5dyTeUTBzm88X.x3ZhhDuptdQ/bB1E3fNxKNyJsDUhLTC', 'uploads/68f18bacbbdf4.jpg', 'membro', '2025-10-16 21:20:09', '2025-10-16 21:19:56', 0),
(21, 'Maria Oliveira', 'maria@gmail.com', '$2y$10$dcMBVjpAI4bI/7oviIpUKeQZM52olVGOUJp3ynIU6PE9.nNp7y356', 'uploads/68f18c193a459.jpg', 'membro', '2025-10-16 21:21:59', '2025-10-16 21:21:45', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `post_id` (`post_id`,`usuario_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_id` (`from_id`),
  ADD KEY `to_id` (`to_id`);

--
-- Índices de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `presence`
--
ALTER TABLE `presence`
  ADD PRIMARY KEY (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de tabela `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de tabela `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT de tabela `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT de tabela `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comentarios_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `mensagens`
--
ALTER TABLE `mensagens`
  ADD CONSTRAINT `mensagens_ibfk_1` FOREIGN KEY (`from_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mensagens_ibfk_2` FOREIGN KEY (`to_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD CONSTRAINT `notificacoes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `presence`
--
ALTER TABLE `presence`
  ADD CONSTRAINT `presence_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
