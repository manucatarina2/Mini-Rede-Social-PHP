<?php
require 'conexao.php';
session_start();

if (!isset($_GET['id'])) exit;

$user_id = (int) $_GET['id'];
$current_user = $_SESSION['user_id'] ?? 0;

// Puxa dados do usuário
$stmt = $conn->prepare("SELECT id, nome, foto FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) exit("<p style='color:#999;text-align:center;'>Usuário não encontrado.</p>");

// Conta seguidores
$stmt_followers = $conn->prepare("SELECT COUNT(*) AS total FROM followers WHERE followed_id = ?");
$stmt_followers->bind_param("i", $user_id);
$stmt_followers->execute();
$followers = $stmt_followers->get_result()->fetch_assoc()['total'] ?? 0;
$stmt_followers->close();

// Verifica se o usuário logado já segue
$stmt_check = $conn->prepare("SELECT 1 FROM followers WHERE follower_id = ? AND followed_id = ?");
$stmt_check->bind_param("ii", $current_user, $user_id);
$stmt_check->execute();
$is_following = $stmt_check->get_result()->num_rows > 0;
$stmt_check->close();

$foto = $user['foto'] ?: 'user.jpg';
$nome = htmlspecialchars($user['nome']);
$btn_text = $is_following ? "Deixar de seguir" : "Seguir";
$btn_color = $is_following ? "#ff7fae" : "#fa8fbd";

echo "
<div style='text-align:center;padding:15px;'>
  <img src='{$foto}' style='width:80px;height:80px;border-radius:50%;object-fit:cover;margin-bottom:8px;'>
  <h3 style='color:#333;margin-bottom:6px;font-size:16px;'>{$nome}</h3>
  <p id='followersCount' style='color:#666;margin-bottom:10px;font-size:13px;'>👥 Seguidores: {$followers}</p>
  <button id='btnFollow' data-id='{$user['id']}' style='background:{$btn_color};color:#fff;padding:8px 12px;border:none;border-radius:8px;cursor:pointer;' data-following='{$is_following}'>
    {$btn_text}
  </button>
</div>
";
$conn->close();
?>
