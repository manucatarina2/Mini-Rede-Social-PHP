<?php
session_start();
require 'conexao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['logado']) || !$_SESSION['logado'] || !isset($_SESSION['user_id'])) {
    echo json_encode(['notificacoes' => 0, 'mensagens' => 0]);
    exit;
}

$user_id = $_SESSION['user_id'];

// Contar notificações não lidas
$notif_stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notificacoes WHERE usuario_id = ? AND lida = 0");
$notif_stmt->bind_param("i", $user_id);
$notif_stmt->execute();
$notif_res = $notif_stmt->get_result()->fetch_assoc();
$notCount = $notif_res['count'] ?? 0;

// Contar mensagens não lidas
$msg_stmt = $conn->prepare("SELECT COUNT(*) AS count FROM mensagens WHERE destinatario_id = ? AND lida = 0");
$msg_stmt->bind_param("i", $user_id);
$msg_stmt->execute();
$msg_res = $msg_stmt->get_result()->fetch_assoc();
$msgCount = $msg_res['count'] ?? 0;

echo json_encode([
    'notificacoes' => $notCount,
    'mensagens' => $msgCount
]);

