<?php
session_start();
require 'conexao.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    if (!empty($email) && !empty($senha)) {
        // Busca usuário no DB
        $stmt = $conn->prepare("SELECT id, nome, foto, senha FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            // Verifica senha hashed
            if (password_verify($senha, $user['senha'])) {
                // Seta sessão
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nome'] = $user['nome'];
                $_SESSION['user_email'] = $email;
                $_SESSION['user_foto'] = $user['foto'] ?? 'uploads/default-profile.jpg';
                $_SESSION['logado'] = true;
                
                // Atualiza last_login no DB (para online)
                $update_stmt = $conn->prepare("UPDATE usuarios SET last_login = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $user['id']);
                $update_stmt->execute();
                
                // Redireciona para feed
                header('Location: index.php');
                exit;
            } else {
                $error = 'Senha incorreta!';
            }
        } else {
            $error = 'Email não encontrado!';
        }
    } else {
        $error = 'Preencha todos os campos!';
    }
}

// Se erro, redireciona de volta para login com mensagem
if ($error) {
    header('Location: login.php?error=' . urlencode($error));
    exit;
}
?>s