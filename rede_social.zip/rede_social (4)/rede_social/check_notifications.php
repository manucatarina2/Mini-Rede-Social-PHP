<?php
session_start();
require 'conexao.php';
header('Content-Type: application/json');

if(!isset($_SESSION['logado'])) exit;

$user_id = $_SESSION['user_id'];

// Notificações não lidas
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notificacoes WHERE usuario_id=? AND lida=0");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$notificacoes = $stmt->get_result()->fetch_assoc()['count'];

// Mensagens não lidas
$stmt2 = $conn->prepare("SELECT COUNT(*) AS count, MAX(created_at) AS ultima FROM mensagens WHERE to_id=? AND lida=0");
$stmt2->bind_param("i",$user_id);
$stmt2->execute();
$msg = $stmt2->get_result()->fetch_assoc();

echo json_encode([
    'notificacoes'=>$notificacoes,
    'mensagens'=>$msg['count'],
    'ultima_msg'=>$msg['ultima']
]);
