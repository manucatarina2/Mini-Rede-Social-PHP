<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar login
function verificarLogin() {
    if (!isset($_SESSION['logado']) || !$_SESSION['logado'] || !isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Limpa texto para saída segura
function limparTexto($texto) {
    return htmlspecialchars(trim($texto), ENT_QUOTES, 'UTF-8');
}

// Formata data (dd/mm/aaaa hh:mm)
function formatarData($data) {
    return date('d/m/Y H:i', strtotime($data));
}
function contar_notificacoes_nao_lidas($conn, $user_id) {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM notificacoes WHERE usuario_id = ? AND lida = 0");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['total'] ?? 0;
}
$nao_lidas = contar_notificacoes_nao_lidas($conn, $_SESSION['user_id']);
?>

<a href="notifications.php">Notificações<?php if($nao_lidas > 0): ?> <span class="badge"><?= $nao_lidas ?></span><?php endif; ?></a>

