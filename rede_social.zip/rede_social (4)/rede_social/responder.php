<?php
session_start();
require 'conexao.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['logado']) || !$_SESSION['logado']) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Verifica se o ID do destinatário foi passado
if (!isset($_GET['para']) || empty($_GET['para'])) {
    header('Location: notificacoes.php');
    exit;
}

$destinatario_id = intval($_GET['para']);

// Busca dados do destinatário
$stmt = $conn->prepare("SELECT nome, foto FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $destinatario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Usuário não encontrado.";
    exit;
}

$destinatario = $result->fetch_assoc();

// Marca todas as mensagens recebidas deste destinatário como lidas
$update_lidas = $conn->prepare("UPDATE mensagens SET lida = 1 WHERE from_id = ? AND to_id = ?");
$update_lidas->bind_param("ii", $destinatario_id, $user_id);
$update_lidas->execute();

// Envio do formulário
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conteudo = trim($_POST['mensagem']);

    if (!empty($conteudo)) {
        $insert = $conn->prepare("INSERT INTO mensagens (from_id, to_id, conteudo, created_at, lida) VALUES (?, ?, ?, NOW(), 0)");
        $insert->bind_param("iis", $user_id, $destinatario_id, $conteudo);
        $insert->execute();

        // Redireciona para o chat com o destinatário
        header("Location: chat.php?para=" . $destinatario_id);
        exit;
    } else {
        $erro = "Digite uma mensagem antes de enviar.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Responder - XoXo</title>
<style>
body { font-family: "Poppins", sans-serif; background: #f5f5f5; padding: 40px; }
.container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
h2 { text-align: center; margin-bottom: 20px; color: #e94089; }
.user-info { display: flex; align-items: center; gap: 15px; margin-bottom: 20px; }
.user-info img, .user-info .avatar { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:24px; background:#ccc; color:#fff; }
form textarea { width: 100%; height: 120px; padding: 10px; border-radius: 8px; border: 1px solid #ccc; resize: none; font-size: 16px; }
form button { margin-top: 15px; background: #e94089; border: none; color: white; padding: 10px 20px; border-radius: 8px; font-size: 16px; cursor: pointer; }
form button:hover { background: #c11760; }
.voltar { display: block; text-align: center; margin-top: 20px; text-decoration: none; color: #e94089; font-weight: bold; }
.erro { color: red; text-align: center; margin-top: 10px; }
</style>
</head>
<body>

<div class="container">
    <h2>Responder Mensagem</h2>

    <div class="user-info">
        <?php if ($destinatario['foto'] && file_exists($destinatario['foto'])): ?>
            <img src="<?= htmlspecialchars($destinatario['foto']) ?>" alt="Destinatário">
        <?php else: ?>
            <div class="avatar"><?= strtoupper($destinatario['nome'][0]) ?></div>
        <?php endif; ?>
        <div>
            <strong><?= htmlspecialchars($destinatario['nome']) ?></strong>
        </div>
    </div>

    <?php if ($erro): ?>
        <div class="erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <textarea name="mensagem" placeholder="Digite sua resposta..." required></textarea>
        <button type="submit">Enviar Resposta</button>
    </form>

    <a class="voltar" href="chat.php?para=<?= $destinatario_id ?>">← Voltar para o chat</a>
</div>

</body>
</html>