<?php
session_start();
require 'conexao.php';

if (!isset($_SESSION['logado']) || !$_SESSION['logado']) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Definir msg_nao_lidas antes de usar
$msg_nao_lidas = 0;
$stmtMsg = $conn->prepare("
    SELECT COUNT(*) AS qtd 
    FROM mensagens 
    WHERE to_id = ? AND lida = 0
");
$stmtMsg->bind_param("i", $user_id);
$stmtMsg->execute();
$resMsg = $stmtMsg->get_result()->fetch_assoc();
if ($resMsg && isset($resMsg['qtd'])) {
    $msg_nao_lidas = intval($resMsg['qtd']);
}

// Talvez você também tem outra variável $nao_lidas (para notificações)? Defina também se necessário:
$nao_lidas = 0;
// exemplo para notificações:
$stmtNotif = $conn->prepare("
    SELECT COUNT(*) AS qtd 
    FROM notificacoes 
    WHERE usuario_id = ? AND lida = 0
");
$stmtNotif->bind_param("i", $user_id);
$stmtNotif->execute();
$resNotif = $stmtNotif->get_result()->fetch_assoc();
if ($resNotif && isset($resNotif['qtd'])) {
    $nao_lidas = intval($resNotif['qtd']);
}

// Verificar post_id
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}
$post_id = intval($_GET['id']);

// Inserção de comentário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['conteudo'])) {
    $conteudo = trim($_POST['conteudo']);
    if ($conteudo !== '') {
        $stmt = $conn->prepare("INSERT INTO comentarios (post_id, usuario_id, conteudo, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $post_id, $user_id, $conteudo);
        $stmt->execute();
        header("Location: ver_post.php?id=$post_id");
        exit;
    }
}

// Buscar dados do usuário atual
$stmtUser = $conn->prepare("SELECT nome, email, foto FROM usuarios WHERE id = ?");
$stmtUser->bind_param("i", $user_id);
$stmtUser->execute();
$currentUser = $stmtUser->get_result()->fetch_assoc();

// Buscar o post
$stmt = $conn->prepare("
    SELECT p.*, u.nome, u.foto,
           (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS total_likes,
           (SELECT COUNT(*) FROM comentarios WHERE post_id = p.id) AS total_comentarios,
           EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id = p.id AND l2.usuario_id = ?) AS curtiu
    FROM posts p
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.id = ?
");
$stmt->bind_param("ii", $user_id, $post_id);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();

if (!$post) {
    echo "Post não encontrado.";
    exit;
}

$post['foto'] = (!empty($post['foto']) && file_exists($post['foto'])) ? $post['foto'] : 'user.jpg';

// Buscar comentários
$comentarios_stmt = $conn->prepare("
    SELECT c.*, u.nome 
    FROM comentarios c
    JOIN usuarios u ON c.usuario_id = u.id
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC
");
$comentarios_stmt->bind_param("i", $post_id);
$comentarios_stmt->execute();
$comentarios = $comentarios_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Post de <?= htmlspecialchars($post['nome']) ?> - XoXo</title>
<style>
/* ===== RESET E BASE ===== */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body {
  display: flex;
  min-height: 100vh;
  background-color: #ffa8ceff;
  position: relative;
}
body::before {
  content: "";
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.7);
}

.main-content,
.sidebar,
.top-bar {
  position: relative;
  z-index: 1;
}

/* ===== SIDEBAR ===== */
.sidebar {
  width: 280px;
  background: linear-gradient(135deg, #fa8fbdff, #f84a95ff);
  color: #fff;
  display: flex;
  flex-direction: column;
  padding: 40px 20px;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  z-index: 1000;
  transition: all 0.3s ease;
}
.sidebar.hidden {
  transform: translateX(-100%);
}
/* Nome do usuário na SIDEBAR — branco */
.sidebar .user-name {
  color: #fff;
}

/* Nome do usuário no CONTAINER (post, etc) — rosa */
.post-info .user-name,
.post-header h1 {
  color: #d31977;
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 30px;
}
.logo-container img {
  height: 40px;
  width: auto;
}
.menu {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.menu a {
  color: #fff;
  text-decoration: none;
  font-weight: 500;
  font-size: 16px;
  padding: 10px 15px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 10px;
  transition: background 0.2s ease, transform 0.2s ease;
}
.menu a:hover {
  background: rgba(255, 255, 255, 0.15);
  transform: translateX(5px);
}
.menu a.active {
  background: rgba(255, 255, 255, 0.25);
  font-weight: 700;
}
.badge {
  background: #ff4757;
  color: white;
  border-radius: 50%;
  padding: 2px 6px;
  font-size: 12px;
  margin-left: 5px;
  font-weight: bold;
}
.user-profile-sidebar {
  margin-top: auto;
  padding: 20px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  display: flex;
  align-items: center;
  gap: 15px;
}
.user-avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
}
.user-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.user-details {
  display: flex;
  flex-direction: column;
}
.user-name {
  font-weight: 600;
  color: #ff69b4;
  font-size: 16px;
}
.user-email {
  font-size: 14px;
  color: #eee;
}

/* ===== TOP BAR ===== */
.top-bar {
  position: fixed;
  left: 280px;
  right: 0;
  top: 0;
  height: 60px;
  background: rgba(255, 255, 255, 0.9);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  color: #333;
  z-index: 999;
  transition: left 0.3s ease;
}
.top-bar.sidebar-hidden {
  left: 0;
  width: 100%;
}
.menu-toggle {
  background: none;
  border: none;
  cursor: pointer;
  color: #333;
}
.menu-toggle svg {
  width: 24px;
  height: 24px;
}
.user-greeting {
  font-size: 18px;
  font-weight: 500;
  color: #333;
}

/* ===== MAIN CONTENT ===== */
.main-content {
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  padding: 100px 40px 40px 40px; /* 100px do topo */
  align-items: center;
  transition: all 0.3s ease;
}
.main-content.sidebar-hidden {
  margin-left: 0;
}

/* ===== POST CONTAINER ===== */
.post-container {
  background: rgba(255, 255, 255, 0.9);
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  max-width: 700px;
  width: 100%;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  margin-top: 0; /* sem margem extra porque já usamos padding-top na main-content */
}
.post-container:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
}
.post-header img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  object-fit: cover;
  background: #eee;
}
.post-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}

/* ===== POST INFO ===== */
.post-info h1 {
  margin-bottom: 5px;
  font-size: 22px;
  color: #d31977;
}
.post-info p {
  font-size: 14px;
  color: #777;
}

/* ===== COMENTÁRIOS ===== */
.comments-section {
  margin-top: 40px;
  background: rgba(255, 255, 255, 0.85);
  padding: 25px;
  border-radius: 12px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
  max-width: 700px;
  width: 100%;
}
.comments-section h3 {
  margin-bottom: 15px;
  color: #d31977;
  font-size: 20px;
}
.comentario {
  background: #fff1f7;
  padding: 12px 15px;
  border-radius: 8px;
  margin-bottom: 10px;
}
.comentario strong {
  color: #d31977;
}
.comentario small {
  color: #999;
  font-size: 12px;
  display: block;
  margin-top: 5px;
}
textarea[name="conteudo"] {
  width: 100%;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #ccc;
  margin-top: 10px;
  resize: vertical;
  font-size: 14px;
}
button[type="submit"] {
  margin-top: 10px;
  padding: 10px 20px;
  background: #f84a95;
  border: none;
  color: #fff;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: background 0.2s ease, transform 0.2s ease;
}
button[type="submit"]:hover {
  background: #d31977;
  transform: translateY(-2px);
}

/* ===== RESPONSIVO ===== */
@media (max-width: 900px) {
  body {
    flex-direction: column;
  }
  .sidebar {
    width: 100%;
    position: relative;
    padding: 30px;
    text-align: center;
    transform: translateX(0);
  }
  .menu a {
    display: inline-block;
    margin: 5px 0;
  }
  .main-content {
    margin-left: 0;
    padding: 100px 20px 20px 20px;
  }
  .post-container {
    padding: 20px;
  }
  .comments-section {
    padding: 15px;
  }
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
  <div class="logo-container">
    <img src="logo.png" alt="Logo">
    <img src="image.png" alt="XoXo">
  </div>

  <div class="menu">
    <a href="index.php">
      <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg> Feed
    </a>
    <a href="perfil.php">
      <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8V22h19.2v-2.8c0-3.2-6.4-4.8-9.6-4.8z"/></svg> Perfil
    </a>
    <a href="chat.php">
      <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M4 4h16v12H5.17L4 17.17V4z"/></svg> Mensagens
      <?php if ($msg_nao_lidas > 0): ?><span class="badge"><?= $msg_nao_lidas ?></span><?php endif; ?>
    </a>
    <a href="notifications.php">
      <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5S10 3.17 10 4v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg> Notificações
      <?php if ($nao_lidas > 0): ?><span class="badge"><?= $nao_lidas ?></span><?php endif; ?>
    </a>
    <a href="logout.php">
      <svg width="20" height="20" fill="#fff" viewBox="0 0 24 24"><path d="M16 13v-2H7V8l-5 4 5 4v-3z"/></svg> Sair
    </a>
  </div>
  <div class="user-profile-sidebar">
    <div class="user-avatar">
      <img src="<?= !empty($currentUser['foto']) && file_exists($currentUser['foto']) ? htmlspecialchars($currentUser['foto']) : 'user.jpg' ?>" alt="Avatar">
    </div>
    <div class="user-details">
      <div class="user-name"><?= htmlspecialchars($currentUser['nome']) ?></div>
      <div class="user-email"><?= htmlspecialchars($currentUser['email']) ?></div>
    </div>
  </div>
</div>

<!-- TOP BAR -->
<div class="top-bar" id="topBar">
  <button class="menu-toggle" onclick="toggleSidebar()">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="#333"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
  </button>
  <div class="user-greeting">Olá, <?= htmlspecialchars($currentUser['nome']) ?>!</div>
</div>

<!-- MAIN CONTENT -->
<div class="main-content" id="mainContent">
  <div class="post-container" style="max-width: 700px; margin: 0 auto;">
    <div class="post-header">
      <img src="<?= htmlspecialchars($post['foto']) ?>" alt="Foto de <?= htmlspecialchars($post['nome']) ?>">
      <div class="post-info">
        <h1><?= htmlspecialchars($post['nome']) ?></h1>
        <p>Publicado em: <?= date('d/m/Y H:i', strtotime($post['created_at'])) ?></p>
      </div>
    </div>
    <div class="post-body"><?= nl2br(htmlspecialchars($post['conteudo'])) ?></div>
    <?php if (!empty($post['imagem']) && file_exists($post['imagem'])): ?>
      <img class="post-image" src="<?= htmlspecialchars($post['imagem']) ?>" alt="Imagem do post">
    <?php endif; ?>
    <div class="post-meta">
      Likes: <?= $post['total_likes'] ?> |
      Comentários: <?= $post['total_comentarios'] ?>
    </div>
  </div>

  <!-- Comentários -->
  <div class="comments-section">
    <h3>Comentários (<?= $post['total_comentarios'] ?>)</h3>
    <?php if (empty($comentarios)): ?>
      <p>Nenhum comentário ainda.</p>
    <?php else: ?>
      <?php foreach ($comentarios as $comentario): ?>
        <div class="comentario">
          <strong><?= htmlspecialchars($comentario['nome']) ?>:</strong>
          <div><?= nl2br(htmlspecialchars($comentario['conteudo'])) ?></div>
          <small><?= date('d/m/Y H:i', strtotime($comentario['created_at'])) ?></small>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <form method="post">
      <textarea name="conteudo" rows="3" required placeholder="Escreva seu comentário aqui..."></textarea>
      <button type="submit">Comentar</button>
    </form>
  </div>
</div>

<script>
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('hidden');
  document.getElementById('topBar').classList.toggle('sidebar-hidden');
  document.getElementById('mainContent').classList.toggle('sidebar-hidden');
}
</script>

</body>
</html>
