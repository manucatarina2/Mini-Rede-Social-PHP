<?php
session_start();
require 'conexao.php';
header('Content-Type: application/json');

// Verifica se logado (segurança)
if (!isset($_SESSION['logado']) || !$_SESSION['logado']) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado. Faça login novamente.']);
    exit;
}

$user_id = $_SESSION['user_id']; // Usa sessão, não POST
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ================== CRIAR POST ==================
    case 'create_post':
        $conteudo = trim($_POST['conteudo'] ?? '');
        if (empty($conteudo)) {
            echo json_encode(['success' => false, 'error' => 'Conteúdo obrigatório!']);
            exit;
        }

        $imagemPath = null;
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $filename = uniqid() . '_' . basename($_FILES['imagem']['name']);
            $imagemPath = $upload_dir . $filename;

            if (!move_uploaded_file($_FILES['imagem']['tmp_name'], $imagemPath)) {
                echo json_encode(['success' => false, 'error' => 'Erro no upload de imagem.']);
                exit;
            }
        }

        $stmt = $conn->prepare("INSERT INTO posts (usuario_id, conteudo, imagem, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iss", $user_id, $conteudo, $imagemPath);
        $success = $stmt->execute();
        echo json_encode(['success' => $success]);
        break;

    // ================== CURTIR POST ==================
    case 'like_post':
        $post_id = (int)($_POST['post_id'] ?? 0);
        if ($post_id <= 0) {
            echo json_encode(['success' => false, 'error' => 'Post inválido.']);
            exit;
        }

        $check_stmt = $conn->prepare("SELECT id FROM likes WHERE usuario_id = ? AND post_id = ?");
        $check_stmt->bind_param("ii", $user_id, $post_id);
        $check_stmt->execute();
        $res = $check_stmt->get_result();

        $liked = false;
        if ($res->num_rows > 0) {
            $stmt = $conn->prepare("DELETE FROM likes WHERE usuario_id = ? AND post_id = ?");
            $stmt->bind_param("ii", $user_id, $post_id);
            $stmt->execute();
        } else {
            $stmt = $conn->prepare("INSERT INTO likes (usuario_id, post_id, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $user_id, $post_id);
            $stmt->execute();
            $liked = true;

            // Notificação
            $post_owner_stmt = $conn->prepare("SELECT usuario_id FROM posts WHERE id = ?");
            $post_owner_stmt->bind_param("i", $post_id);
            $post_owner_stmt->execute();
            $post_owner_id = $post_owner_stmt->get_result()->fetch_assoc()['usuario_id'];

            if ($post_owner_id != $user_id) {
                $notif_stmt = $conn->prepare("INSERT INTO notificacoes (usuario_id, origem_usuario_id, tipo, referencia_id, mensagem, lida, created_at) VALUES (?, ?, 'like', ?, ?, 0, NOW())");
                $mensagem_notif = "Curtiram sua publicação";
                $notif_stmt->bind_param("iiis", $post_owner_id, $user_id, $post_id, $mensagem_notif);
                $notif_stmt->execute();
            }
        }

        $count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM likes WHERE post_id = ?");
        $count_stmt->bind_param("i", $post_id);
        $count_stmt->execute();
        $total_likes = $count_stmt->get_result()->fetch_assoc()['total'];

        echo json_encode(['success' => true, 'liked' => $liked, 'total_likes' => $total_likes]);
        break;

    // ================== ADICIONAR COMENTÁRIO ==================
    case 'add_comment':
        $post_id = intval($_POST['post_id'] ?? 0);
        $conteudo = trim($_POST['conteudo'] ?? '');
        if ($post_id <= 0 || $conteudo === '') {
            echo json_encode(['success' => false, 'error' => 'Comentário inválido.']);
            exit;
        }

        $check = $conn->prepare("SELECT id, usuario_id FROM posts WHERE id = ?");
        $check->bind_param("i", $post_id);
        $check->execute();
        $post_data = $check->get_result()->fetch_assoc();
        if (!$post_data) {
            echo json_encode(['success' => false, 'error' => 'Post não encontrado.']);
            exit;
        }
        $post_owner_id = $post_data['usuario_id'];

        $stmt = $conn->prepare("INSERT INTO comentarios (post_id, usuario_id, conteudo, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $post_id, $user_id, $conteudo);
        $ok = $stmt->execute();

        if ($ok) {
            $count = $conn->prepare("SELECT COUNT(*) as total FROM comentarios WHERE post_id = ?");
            $count->bind_param("i", $post_id);
            $count->execute();
            $total = $count->get_result()->fetch_assoc()['total'] ?? 0;

            if ($post_owner_id != $user_id) {
                $notif_stmt = $conn->prepare("INSERT INTO notificacoes (usuario_id, origem_usuario_id, tipo, referencia_id, mensagem, lida, created_at) VALUES (?, ?, 'comentario', ?, ?, 0, NOW())");
                $mensagem_notif = "Comentou na sua publicação";
                $notif_stmt->bind_param("iiis", $post_owner_id, $user_id, $post_id, $mensagem_notif);
                $notif_stmt->execute();
            }

            echo json_encode(['success' => true, 'total_comentarios' => $total]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Erro ao salvar comentário.']);
        }
        break;

    // ================== PEGAR COMENTÁRIOS ==================
    case 'get_comments':
        $post_id = intval($_GET['post_id'] ?? 0);
        $stmt = $conn->prepare("
            SELECT c.conteudo, c.created_at, u.nome
            FROM comentarios c
            JOIN usuarios u ON c.usuario_id = u.id
            WHERE c.post_id = ?
            ORDER BY c.created_at ASC
        ");
        $stmt->bind_param("i", $post_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $comments = [];
        while ($row = $result->fetch_assoc()) {
            $comments[] = $row;
        }
        echo json_encode($comments);
        break;

    // ================== SEGUIR / DEIXAR DE SEGUIR ==================
    case 'follow_user':
        $target_id = intval($_POST['target_id'] ?? 0);
        if ($target_id <= 0 || $target_id == $user_id) {
            echo json_encode(['success' => false, 'error' => 'Usuário inválido.']);
            exit;
        }

        $check_stmt = $conn->prepare("SELECT id FROM seguidores WHERE usuario_id = ? AND seguido_id = ?");
        $check_stmt->bind_param("ii", $user_id, $target_id);
        $check_stmt->execute();
        $res = $check_stmt->get_result();

        $isFollowing = false;
        if ($res->num_rows > 0) {
            $stmt = $conn->prepare("DELETE FROM seguidores WHERE usuario_id = ? AND seguido_id = ?");
            $stmt->bind_param("ii", $user_id, $target_id);
            $stmt->execute();
        } else {
            $stmt = $conn->prepare("INSERT INTO seguidores (usuario_id, seguido_id, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $user_id, $target_id);
            $stmt->execute();
            $isFollowing = true;

            $notif_stmt1 = $conn->prepare("INSERT INTO notificacoes (usuario_id, origem_usuario_id, tipo, mensagem, created_at, lida) VALUES (?, ?, 'seguir', ?, NOW(), 0)");
            $mensagem1 = "Começou a te seguir";
            $notif_stmt1->bind_param("iis", $target_id, $user_id, $mensagem1);
            $notif_stmt1->execute();

            $stmtNome = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
            $stmtNome->bind_param("i", $target_id);
            $stmtNome->execute();
            $nomeTarget = $stmtNome->get_result()->fetch_assoc()['nome'] ?? '';
            $notif_stmt2 = $conn->prepare("INSERT INTO notificacoes (usuario_id, origem_usuario_id, tipo, mensagem, created_at, lida) VALUES (?, ?, 'seguido', ?, NOW(), 0)");
            $mensagem2 = "Você começou a seguir $nomeTarget";
            $notif_stmt2->bind_param("iis", $user_id, $target_id, $mensagem2);
            $notif_stmt2->execute();
        }

        echo json_encode(['success' => true, 'following' => $isFollowing]);
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Ação inválida']);
        break;
}
