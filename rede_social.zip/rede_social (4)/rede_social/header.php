<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mini Rede Social</title>
<link rel="stylesheet" href="/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container header-inner">
    <a href="index.php" class="brand">MiniSocial</a>
    <nav>
      <?php if (isset($_SESSION['usuario'])): ?>
        <a href="create_post.php">Nova Postagem</a>
        <a href="chat.php">Chat</a>
        <a href="notifications.php">Notificações</a>
        <a href="profile.php">Perfil</a>
        <a href="/logout.php" class="btn-logout">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
        <a href="register.php">Cadastro</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
