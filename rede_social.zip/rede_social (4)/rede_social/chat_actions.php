<?php
session_start();
require 'conexao.php';
header('Content-Type: application/json');

// Verifica se logado
if (!isset($_SESSION['logado']) || !$_SESSION['logado'] || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado. Faça login.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Pega nome do usuário logado (para notificações)
$stmt_user = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$currentUser = $stmt_user->get_result()->fetch_assoc();
$user_nome = $currentUser['nome'] ?? 'Usuário';

switch ($action) {

    case 'send':
        $to_id = (int) ($_POST['to'] ?? 0);
        $conteudo = trim($_POST['message'] ?? '');

        if ($to_id <= 0 || empty($conteudo) || $to_id == $user_id) {
            echo json_encode(['success' => false, 'error' => 'Destinatário ou mensagem inválida.']);
            exit;
        }

        // Insere mensagem
        $stmt = $conn->prepare("INSERT INTO mensagens (from_id, to_id, conteudo, created_at, lida) VALUES (?, ?, ?, NOW(), 0)");
        $stmt->bind_param("iis", $user_id, $to_id, $conteudo);
        $success = $stmt->execute();
        $message_id = $conn->insert_id;
        

        if ($success) {
            // Cria notificação
            $notif_conteudo = $user_nome . " enviou uma mensagem: '" . substr($conteudo, 0, 50) . (strlen($conteudo) > 50 ? '...' : '') . "'";

            $notif_stmt = $conn->prepare("
                INSERT INTO notificacoes (usuario_id, origem_usuario_id, tipo, referencia_id, mensagem, lida, created_at)
                VALUES (?, ?, 'mensagem', ?, ?, 0, NOW())
            ");
            $notif_stmt->bind_param("iiis", $to_id, $user_id, $message_id, $notif_conteudo);
            $notif_stmt->execute();

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Erro ao enviar mensagem.']);
        }
        break;

    case 'load':
        $to_id = (int) ($_GET['to'] ?? 0);
        if ($to_id <= 0 || $to_id == $user_id) {
            echo json_encode([]);
            exit;
        }

        // Carrega mensagens entre user_id e to_id
        $stmt = $conn->prepare("
            SELECT m.id, m.from_id, m.to_id, m.conteudo, m.created_at, m.lida 
            FROM mensagens m 
            WHERE (m.from_id = ? AND m.to_id = ?) OR (m.from_id = ? AND m.to_id = ?) 
            ORDER BY m.created_at ASC 
            LIMIT 50
        ");
        $stmt->bind_param("iiii", $user_id, $to_id, $to_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = $result->fetch_all(MYSQLI_ASSOC);

        // Marca mensagens recebidas como lidas
        $mark_read_stmt = $conn->prepare("UPDATE mensagens SET lida = 1 WHERE to_id = ? AND from_id = ? AND lida = 0");
        $mark_read_stmt->bind_param("ii", $user_id, $to_id);
        $mark_read_stmt->execute();

        // Formata timestamps
        foreach ($messages as &$msg) {
            $msg['created_at'] = date('Y-m-d H:i:s', strtotime($msg['created_at']));
        }

        echo json_encode($messages);
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Ação inválida.']);
        break;
}
?>
