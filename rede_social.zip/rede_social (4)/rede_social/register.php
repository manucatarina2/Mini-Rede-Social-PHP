<?php
session_start();
require 'conexao.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $nivel = 'membro';

    // Verifica se o email já existe
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Este e-mail já está cadastrado.";
    } else {
        // Upload da foto (opcional)
        $fotoPath = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $extensao = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $nomeArquivo = uniqid() . "." . $extensao;
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $fotoPath = $uploadDir . $nomeArquivo;
            move_uploaded_file($_FILES['foto']['tmp_name'], $fotoPath);
        }

        // Inserir usuário
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, foto, nivel) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nome, $email, $senha, $fotoPath, $nivel);

        if ($stmt->execute()) {
            $success = "Cadastro realizado com sucesso!";
        } else {
            $error = "Erro ao cadastrar usuário: " . $conn->error;
        }
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>XoXo - Cadastro</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: "Poppins", sans-serif; }
    body { display: flex; height: 100vh; background-color: #fff; }

    .left {
      flex: 1;
      position: relative;
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 40px;
      overflow: hidden;
    }

    .left::before {
      content: "";
      position: absolute;
      inset: 0;
      background:
        linear-gradient(rgba(236, 72, 153, 0.6), rgba(190, 24, 93, 0.6)),
        url("fundo.png") center/cover no-repeat;
      opacity: 0.7;
      z-index: 0;
    }

    .left img,
    .left h1,
    .left p {
      position: relative;
      z-index: 1;
    }

    .left h1 {
      font-size: 48px;
      font-weight: 700;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .left p {
      font-size: 16px;
      line-height: 1.6;
      max-width: 400px;
    }

    .right {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #fff;
    }

    .login-box {
      width: 360px;
    }

    .login-box h2 {
      text-align: center;
      font-size: 28px;
      font-weight: 700;
      color: #222;
      margin-bottom: 30px;
    }

    .login-box label {
      font-size: 14px;
      font-weight: 500;
      color: #444;
    }

    .login-box input {
      width: 100%;
      padding: 12px;
      margin: 8px 0 18px;
      border: 1px solid #eee;
      border-radius: 8px;
      background-color: #f9f9f9;
      font-size: 14px;
    }

    .login-box input:focus {
      outline: none;
      border-color: #e94089;
      background-color: #fff;
    }

    .login-box button {
      width: 100%;
      background: linear-gradient(135deg, #fa8fbdff, #f84a95ff);
      border: none;
      color: white;
      font-size: 15px;
      font-weight: 600;
      padding: 12px;
      border-radius: 25px;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .login-box button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(233, 64, 137, 0.4);
    }

    .login-box .register {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
      color: #aaa;
    }

    .login-box .register a {
      color: #e94089;
      font-weight: 500;
      text-decoration: none;
    }

    .login-box .register a:hover {
      text-decoration: underline;
    }

    .error, .success {
      text-align: center;
      margin: 10px 0;
      padding: 10px;
      border-radius: 5px;
      display: block;
    }

    .error {
      color: red;
      background: #ffe6e6;
    }

    .success {
      color: #10b981;
      background: #e6fffa;
    }

    @media (max-width: 900px) {
      body { flex-direction: column; }
      .left { height: 45vh; padding: 30px; }
      .left h1 { font-size: 40px; }
      .right { height: 55vh; }
      .login-box { width: 90%; }
    }
  </style>
</head>
<body>

  <!-- LADO ESQUERDO -->
  <div class="left">
    <img src="logo.png" alt="Logo XoXo"><br>
    <h1>Bem-vindo<br>à XoXo!</h1>
    <p>Cadastre-se e entre para a comunidade mais charmosa da internet. Segredos, risadas e conexões reais esperam por você.</p>
  </div>

  <!-- LADO DIREITO -->
  <div class="right">
    <form class="login-box" method="POST" enctype="multipart/form-data">
      <h2>Cadastrar</h2>

      <?php if($error): ?>
        <div class="error"><?= $error ?></div>
      <?php endif; ?>

      <?php if($success): ?>
        <div class="success"><?= $success ?></div>
      <?php endif; ?>

      <label for="nome">Nome</label>
      <input type="text" id="nome" name="nome" placeholder="Seu nome" required>

      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="seuemail@gmail.com" required>

      <label for="senha">Senha</label>
      <input type="password" id="senha" name="senha" placeholder="••••••••" required>

      <label for="foto">Foto de perfil (opcional)</label>
      <input type="file" id="foto" name="foto" accept="image/*">

      <button type="submit">Cadastrar</button>

      <div class="register">
        Já tem uma conta? <a href="login.php">Entre aqui</a>
      </div>
    </form>
  </div>

</body>
</html>
