* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body {
  display: flex;
  min-height: 100vh;
  background-color: #f5f5f5;
}

/* ===== SIDEBAR ===== */
.sidebar {
  width: 280px;
  background: linear-gradient(135deg, #e94089, #c11760);
  color: #fff;
  display: flex;
  flex-direction: column;
  padding: 40px 20px;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
}
.sidebar h1 {
  font-size: 36px;
  font-weight: 700;
  margin-bottom: 30px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.sidebar h1::before {
  content: "♥";
  font-size: 24px;
  color: #fff;
}
.menu {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.menu a {
  color: #fff;
  text-decoration: none;
  font-weight: 500;
  font-size: 16px;
  padding: 10px 15px;
  border-radius: 8px;
  transition: background 0.2s ease, transform 0.2s ease;
}
.menu a:hover {
  background: rgba(255, 255, 255, 0.15);
  transform: translateX(5px);
}
.menu a.active {
  background: rgba(255, 255, 255, 0.25);
  font-weight: 700;
}
.badge {
  background: #ff4757;
  color: white;
  border-radius: 50%;
  padding: 2px 6px;
  font-size: 12px;
  margin-left: 5px;
  font-weight: bold;
}

/* ===== MAIN CONTENT ===== */
.main-content {
  margin-left: 300px; /* espaço para a sidebar fixa */
  flex: 1;
  padding: 40px;
  display: flex;
  flex-direction: column;
  background-color: #fff;
}
.main-content h1 {
  font-size: 32px;
  color: #222;
  margin-bottom: 30px;
}



/

  .sidebar {
    width: 100%;
    position: relative;
    padding: 30px;
    text-align: center;
  }
  .menu a {
    display: inline-block;
    margin: 5px 0;
  }
  .main-content {
    margin-left: 0;
    padding: 20px;
  }
 
