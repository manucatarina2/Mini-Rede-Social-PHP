<?php
require '../conexao.php';
session_start();
header('Content-Type: application/json');
if(!isset($_SESSION['usuario'])) { echo json_encode(['ok'=>false]); exit; }
$id = (int)$_POST['id']; $uid = $_SESSION['usuario']['id'];
$stmt = $conn->prepare('UPDATE notificacoes SET lida=1 WHERE id=? AND usuario_id=?'); $stmt->bind_param('ii',$id,$uid); $stmt->execute();
echo json_encode(['ok'=>true]);
