<?php
require 'conexao.php';
session_start();
header('Content-Type: application/json');

// ===== VERIFICA LOGIN =====
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autenticado']);
    exit;
}

$follower_id = $_SESSION['user_id'];
$followed_id = intval($_POST['id'] ?? 0);

if ($followed_id <= 0 || $followed_id == $follower_id) {
    echo json_encode(['success' => false, 'error' => 'Operação inválida.']);
    exit;
}

// ===== VERIFICA SE JÁ SEGUE =====
$stmtCheck = $conn->prepare("SELECT id, status FROM followers WHERE follower_id = ? AND followed_id = ?");
$stmtCheck->bind_param("ii", $follower_id, $followed_id);
$stmtCheck->execute();
$res = $stmtCheck->get_result()->fetch_assoc();

if ($res) {
    if ($res['status'] == 1) {
        // Já segue → parar de seguir
        $stmtUpdate = $conn->prepare("UPDATE followers SET status = 0 WHERE id = ?");
        $stmtUpdate->bind_param("i", $res['id']);
        $stmtUpdate->execute();

        // Remove notificação anterior
        $stmtDelNotif = $conn->prepare("DELETE FROM notificacoes WHERE tipo='follow' AND remetente_id=? AND usuario_id=?");
        $stmtDelNotif->bind_param("ii", $follower_id, $followed_id);
        $stmtDelNotif->execute();

        echo json_encode(['success' => true, 'action' => 'unfollow']);
        exit;
    } else {
        // Reativar follow
        $stmtUpdate = $conn->prepare("UPDATE followers SET status = 1, created_at = NOW() WHERE id = ?");
        $stmtUpdate->bind_param("i", $res['id']);
        $stmtUpdate->execute();

        // Cria nova notificação
        $stmtNotif = $conn->prepare("
            INSERT INTO notificacoes (usuario_id, remetente_id, tipo, conteudo, lida, created_at)
            VALUES (?, ?, 'follow', 'Você tem um novo seguidor!', 0, NOW())
        ");
        $stmtNotif->bind_param("ii", $followed_id, $follower_id);
        $stmtNotif->execute();

        echo json_encode(['success' => true, 'action' => 'follow']);
        exit;
    }
} else {
    // Novo follow
    $stmt = $conn->prepare("INSERT INTO followers (follower_id, followed_id, status, created_at) VALUES (?, ?, 1, NOW())");
    $stmt->bind_param("ii", $follower_id, $followed_id);
    $stmt->execute();

    $stmtNotif = $conn->prepare("
    INSERT INTO notificacoes (usuario_id, usuario_acao_id, tipo, mensagem, lida, created_at)
    VALUES (?, ?, 'follow', 'Você tem um novo seguidor!', 0, NOW())
");
$stmtNotif->bind_param("ii", $followed_id, $follower_id);
$stmtNotif->execute();


    echo json_encode(['success' => true, 'action' => 'follow']);
    exit;
}
?>
