<?php
session_start();
require 'conexao.php';
header('Content-Type: application/json');

// Verifica login
if (!isset($_SESSION['logado']) || !$_SESSION['logado'] || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado.']);
    exit;
}

$user_id = (int)($_GET['id'] ?? 0);
if ($user_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido.']);
    exit;
}

// Busca usuário
$stmt = $conn->prepare("SELECT id, nome, email, foto FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Usuário não encontrado.']);
    exit;
}

// Verifica foto
$user['foto'] = !empty($user['foto']) && file_exists($user['foto']) ? $user['foto'] : 'user.jpg';

echo json_encode($user);
